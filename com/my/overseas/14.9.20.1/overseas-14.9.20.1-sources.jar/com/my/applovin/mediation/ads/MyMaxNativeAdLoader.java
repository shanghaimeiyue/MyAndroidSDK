package com.my.applovin.mediation.ads;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;
import android.view.ViewGroup;

import com.my.applovin.mediation.MyMaxNativeAdListener;
import com.my.applovin.util.LogUtil;
import com.tradplus.ads.base.bean.TPAdError;
import com.tradplus.ads.base.bean.TPAdInfo;
import com.tradplus.ads.base.bean.TPBaseAd;
import com.tradplus.ads.open.LoadAdEveryLayerListener;
import com.tradplus.ads.open.nativead.NativeAdListener;
import com.tradplus.ads.open.nativead.TPNative;

import java.util.Map;

public class MyMaxNativeAdLoader {

    private TPNative mTPNative;
    private Context mContext;
    private String mAdUnitId;
    private int width;
    private int height;

    public MyMaxNativeAdLoader(String adUnitId, Context context) {
        if ((context instanceof Activity) && !TextUtils.isEmpty(adUnitId.trim())) {
            this.mContext = context;
            this.mAdUnitId = adUnitId;
            this.width = ViewGroup.LayoutParams.MATCH_PARENT;
            this.height = ViewGroup.LayoutParams.WRAP_CONTENT;
            this.mTPNative = new TPNative(context, adUnitId);
        } else {
            LogUtil.i("Error Create an AD that requires acitivity, otherwise it won't load");
        }
    }

    private TPNative getTPNative() {
        return this.mTPNative;
    }

    public void setCustomParams(Map<String, Object> mLocalExtras) {
        if (mTPNative != null) {
            for (Map.Entry<String, Object> entry : mLocalExtras.entrySet()) {
                String key = entry.getKey();
                if (key.equals("width")) {
                    width = (int) entry.getValue();
                } else if (key.equals("height")) {
                    height = (int) entry.getValue();
                }
            }
            if (width > 0 && height > 0) {
                mTPNative.setAdSize(width, height);
            }
            mTPNative.setCustomParams(mLocalExtras);
        }
    }

    public void setAdListener(MyMaxNativeAdListener myMaxNativeAdListener) {
        if (mTPNative != null && myMaxNativeAdListener != null) {
            mTPNative.setAllAdLoadListener(new LoadAdEveryLayerListener() {
                @Override
                public void onAdAllLoaded(boolean b) {

                }

                @Override
                public void oneLayerLoadFailed(TPAdError tpAdError, TPAdInfo tpAdInfo) {
                    myMaxNativeAdListener.oneLayerLoadFailed(tpAdError, tpAdInfo);
                    LogUtil.i("Error: code:" + tpAdError.getErrorCode() + ", Msg:" + tpAdError.getErrorMsg());
                }

                @Override
                public void oneLayerLoaded(TPAdInfo tpAdInfo) {

                }

                @Override
                public void onAdStartLoad(String s) {

                }

                @Override
                public void oneLayerLoadStart(TPAdInfo tpAdInfo) {

                }

                @Override
                public void onBiddingStart(TPAdInfo tpAdInfo) {

                }

                @Override
                public void onBiddingEnd(TPAdInfo tpAdInfo, TPAdError tpAdError) {

                }

                @Override
                public void onAdIsLoading(String s) {

                }
            });
            mTPNative.setAdListener(new NativeAdListener() {
                @Override // 广告加载完成 首个广告源加载成功时回调 一次加载流程只会回调一次
                public void onAdLoaded(TPAdInfo tpAdInfo, TPBaseAd tpBaseAd) {
                    myMaxNativeAdListener.onNativeAdLoaded(tpAdInfo);
                }

                @Override // 广告被点击
                public void onAdClicked(TPAdInfo tpAdInfo) {
                    myMaxNativeAdListener.onNativeAdClicked(tpAdInfo);
                }

                @Override // 广告成功展示在页面上
                public void onAdImpression(TPAdInfo tpAdInfo) {
                    myMaxNativeAdListener.onNativeAdExpired(tpAdInfo);
                }

                @Override // 广告加载失败
                public void onAdLoadFailed(TPAdError tpAdError) {
                    myMaxNativeAdListener.onNativeAdLoadFailed(mAdUnitId, tpAdError);
                }

                @Override // 广告展示失败（部分广告支持）
                public void onAdShowFailed(TPAdError tpAdError, TPAdInfo tpAdInfo) {
                    myMaxNativeAdListener.onNativeAdShowFailed(tpAdError, tpAdInfo);
                }

                @Override // 广告被关闭
                public void onAdClosed(TPAdInfo tpAdInfo) {
                    myMaxNativeAdListener.onNativeAdClosed(tpAdInfo);
                }
            });
        }
    }

    // Load the first ad
    public void loadAd() {
        if (mTPNative != null) {
            mTPNative.loadAd();
        }
    }

    public boolean isReady() {
        return mTPNative != null && mTPNative.isReady();
    }

    public void showAd(ViewGroup adContainer, int itemLayoutInflaterId) {
        if (mTPNative != null) {
            if (mContext instanceof Activity) {
                if (adContainer != null && itemLayoutInflaterId > 0) {
                    mTPNative.showAd(adContainer, itemLayoutInflaterId, "");
                }
            }
        }
    }

    public void onDestroy() {
        if (mTPNative != null) {
            mTPNative.onDestroy();
        }
    }
}
