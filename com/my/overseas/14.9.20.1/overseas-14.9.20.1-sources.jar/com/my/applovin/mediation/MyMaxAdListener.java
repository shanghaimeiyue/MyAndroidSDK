package com.my.applovin.mediation;

import com.tradplus.ads.base.bean.TPAdError;
import com.tradplus.ads.base.bean.TPAdInfo;
import com.tradplus.ads.base.bean.TPBaseAd;

public interface MyMaxAdListener {
    //广告加载完成
    void onAdLoaded(final TPAdInfo tpAdInfo, TPBaseAd tpBaseAd);

    // 广告加载失败
    void onAdLoadFailed(final TPAdError tpAdInfo);

    // 广告被关闭
    void onAdClosed(final TPAdInfo tpAdInfo);

    // 广告成功展示在页面上
    void onAdDisplayed(final TPAdInfo tpAdInfo);

    // 广告被点击
    void onAdClicked(final TPAdInfo tpAdInfo);

    // 广告展示失败
    void onAdDisplayFailed(final TPAdInfo tpAdInfo, final TPAdError tpAdError);

    // 广告失败异常
    void oneLayerLoadFailed(TPAdError tpAdError, TPAdInfo tpAdInfo);
}
