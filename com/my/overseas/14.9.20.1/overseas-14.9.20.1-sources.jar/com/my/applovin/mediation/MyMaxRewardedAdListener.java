package com.my.applovin.mediation;

import com.tradplus.ads.base.bean.TPAdError;
import com.tradplus.ads.base.bean.TPAdInfo;

public interface MyMaxRewardedAdListener {
    // 广告加载完成
    void onAdLoaded(TPAdInfo tpAdInfo);
    // 广告加载失败
    void onAdLoadFailed(String adUnitId, TPAdError tpAdError);
    // 广告成功展示在页面上
    void onAdDisplayed(TPAdInfo maxAd);
    // 广告被点击
    void onAdClicked(TPAdInfo tpAdInfo);
    // 广告被关闭
    void onAdClosed(TPAdInfo tpAdInfo);
    // 视频播放开始
    void onRewardedVideoStarted(TPAdInfo tpAdInfo);
    //视频结束过程：并非是播放结束，而是结束过程
    void onAdVideoEnd(TPAdInfo tpAdInfo);
    //视频播放失败（部分广告源支持）
    void onAdVideoError(TPAdInfo tpAdInfo, TPAdError tpAdError);
    // 激励视频奖励回调
    void onUserRewarded(TPAdInfo tpAdInfo);
    // 广告失败异常
    void oneLayerLoadFailed(TPAdError tpAdError, TPAdInfo tpAdInfo);
}
