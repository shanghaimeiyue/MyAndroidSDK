package com.my.applovin.mediation.ads;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;
import android.view.ViewGroup;

import com.my.applovin.mediation.MyMaxAdListener;
import com.my.applovin.util.LogUtil;
import com.tradplus.ads.base.GlobalTradPlus;
import com.tradplus.ads.base.bean.TPAdError;
import com.tradplus.ads.base.bean.TPAdInfo;
import com.tradplus.ads.base.bean.TPBaseAd;
import com.tradplus.ads.open.LoadAdEveryLayerListener;
import com.tradplus.ads.open.splash.SplashAdListener;
import com.tradplus.ads.open.splash.TPSplash;

import java.util.Map;

public class MyMaxAppOpenAd {
    private TPSplash mTpSplash;
    private Context mContext;
    private String mAdUnitId;

    public MyMaxAppOpenAd(String adUnitId, Context context) {
        if ((context instanceof Activity) && !TextUtils.isEmpty(adUnitId.trim())) {
            this.mContext = context;
            this.mAdUnitId = adUnitId;
            this.mTpSplash = new TPSplash(context, adUnitId);
        } else {
            LogUtil.i("Error Create an AD that requires acitivity, otherwise it won't load");
        }
    }

    private TPSplash getTPSplash() {
        return mTpSplash;
    }

    public void setCustomParams(Map<String, Object> mLocalExtras) {
        if (mTpSplash != null) {
            mTpSplash.setCustomParams(mLocalExtras);
        }
    }

    public void refreshContext(Context context) {
        GlobalTradPlus.getInstance().refreshContext(context);
    }

    public void setListener(MyMaxAdListener maxAdListener) {
        if (mTpSplash != null && maxAdListener != null) {
            mTpSplash.setAllAdLoadListener(new LoadAdEveryLayerListener() {
                @Override
                public void onAdAllLoaded(boolean b) {

                }

                @Override
                public void oneLayerLoadFailed(TPAdError tpAdError, TPAdInfo tpAdInfo) {
                    maxAdListener.oneLayerLoadFailed(tpAdError, tpAdInfo);
                    LogUtil.i("Error: code:" + tpAdError.getErrorCode() + ", Msg:" + tpAdError.getErrorMsg());
                }

                @Override
                public void oneLayerLoaded(TPAdInfo tpAdInfo) {

                }

                @Override
                public void onAdStartLoad(String s) {

                }

                @Override
                public void oneLayerLoadStart(TPAdInfo tpAdInfo) {

                }

                @Override
                public void onBiddingStart(TPAdInfo tpAdInfo) {

                }

                @Override
                public void onBiddingEnd(TPAdInfo tpAdInfo, TPAdError tpAdError) {

                }

                @Override
                public void onAdIsLoading(String s) {

                }
            });
            mTpSplash.setAdListener(new SplashAdListener() {
                @Override
                public void onAdLoaded(TPAdInfo tpAdInfo, TPBaseAd tpBaseAd) {
                    maxAdListener.onAdLoaded(tpAdInfo, tpBaseAd);
                    LogUtil.i("onAdLoaded Successful unitId: " + tpAdInfo.tpAdUnitId);
                }

                @Override
                public void onAdClicked(TPAdInfo tpAdInfo) {
                    maxAdListener.onAdClicked(tpAdInfo);
                }

                @Override
                public void onAdClosed(TPAdInfo tpAdInfo) {
                    maxAdListener.onAdClosed(tpAdInfo);
                }

                @Override
                public void onAdImpression(TPAdInfo tpAdInfo) {
                    maxAdListener.onAdDisplayed(tpAdInfo);
                }

                @Override
                public void onAdLoadFailed(TPAdError tpAdError) {
                    maxAdListener.onAdLoadFailed(tpAdError);
                    LogUtil.i("onAdShowFailed error:" + tpAdError.getErrorCode() + "\n" + tpAdError.getErrorMsg());
                }

                @Override
                public void onAdShowFailed(TPAdInfo tpAdInfo, TPAdError tpAdError) {
                    maxAdListener.onAdDisplayFailed(tpAdInfo, tpAdError);
                    LogUtil.i("onAdShowFailed error:" + tpAdError.getErrorCode() + "\n" + tpAdError.getErrorMsg());
                }
            });
        }
    }

    public void loadAd(ViewGroup adContainer) {
        if (mContext != null && mTpSplash != null) {
            mTpSplash.loadAd(adContainer);
        }
    }

    // 如果开屏需要预加载（提前为热启动做准备），那么在load的时候传入null，show的时候传入容器
    public void loadAd() {
        if (mContext != null && mTpSplash != null) {
            mTpSplash.loadAd(null);
        }
    }

    public void showAd() {
        if (mContext != null && mTpSplash != null) {
            mTpSplash.showAd();
        }
    }

    public void showAd(ViewGroup adContainer) {
        if (mContext != null && mTpSplash != null) {
            mTpSplash.showAd(adContainer);
        }
    }

    public boolean isReady() {
        return mTpSplash != null && mTpSplash.isReady();
    }

    public String getAdUnitId() {
        return mTpSplash != null && !TextUtils.isEmpty(mAdUnitId) ? mAdUnitId : null;
    }

    public void onDestroy() {
        if (mContext != null && mTpSplash != null) {
            mTpSplash.onDestroy();
        }
    }
}
