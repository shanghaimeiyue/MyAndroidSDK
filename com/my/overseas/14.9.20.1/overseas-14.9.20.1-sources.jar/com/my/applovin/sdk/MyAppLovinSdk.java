package com.my.applovin.sdk;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;

import com.facebook.ads.AdSettings;
import com.google.android.gms.ads.identifier.AdvertisingIdClient;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.tradplus.ads.open.TradPlusSdk;

import java.io.IOException;

@SuppressLint("StaticFieldLeak")
public class MyAppLovinSdk {

    private static volatile boolean isTradPlusSdk = false;
    public static volatile boolean isLogcat = false;

    public String getSdkVesion() {
        return BuildConfig.VERSION_AAR;
    }

    private static class SingletonHolder {
        private static final MyAppLovinSdk INSTANCE = new MyAppLovinSdk();
    }

    public static MyAppLovinSdk getInstance() {
        return SingletonHolder.INSTANCE;
    }

    public MyAppLovinSdk setDataProcessingOptions(String[] options) {
        AdSettings.setDataProcessingOptions(options);
        return this;
    }

    public void initializeSdk(Context context, String appId, SdkInitializationListener sdkInitializationListener) {
        new Thread(() -> {
            if (!isTradPlusSdk && context != null) {
                TradPlusSdk.setTradPlusInitListener(new TradPlusSdk.TradPlusInitListener() {
                    @Override
                    public void onInitSuccess() {
                        isTradPlusSdk = TradPlusSdk.getIsInit();
                        if (sdkInitializationListener != null) {
                            sdkInitializationListener.onSdkInitialized();
                        }
                    }
                });
                TradPlusSdk.initSdk(context, appId);
            }
        }).start();
    }

    public void setLogcat(boolean isOpenLogcat) {
        isLogcat = isOpenLogcat;
    }

    public void getGAID(Context context, SdkGoogleGAIDListener googleGAIDListener) {
        new Thread(() -> {
            AdvertisingIdClient.Info adInfo = null;
            try {
                adInfo = AdvertisingIdClient.getAdvertisingIdInfo(context);
            } catch (IOException | GooglePlayServicesNotAvailableException |
                     GooglePlayServicesRepairableException e) {
                e.printStackTrace();
            }
            if (googleGAIDListener != null && adInfo != null) {
                googleGAIDListener.onSdkGAID(adInfo.getId());
            }
        }).start();
    }

    public interface SdkInitializationListener {
        void onSdkInitialized();
    }

    public interface SdkGoogleGAIDListener {
        void onSdkGAID(String gaid);
    }

    public MyAppLovinSdk() {
    }
}
