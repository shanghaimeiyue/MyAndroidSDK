package com.my.applovin.mediation.ads;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;

import com.my.applovin.mediation.MyMaxRewardedAdListener;
import com.my.applovin.util.LogUtil;
import com.tradplus.ads.base.bean.TPAdError;
import com.tradplus.ads.base.bean.TPAdInfo;
import com.tradplus.ads.open.LoadAdEveryLayerListener;
import com.tradplus.ads.open.reward.RewardAdListener;
import com.tradplus.ads.open.reward.TPReward;

import java.util.Map;

public class MyMaxRewardedAd {

    private TPReward mTPReward;
    private Context mContext;
    private String mAdUnitId;

    private static class SingletonHolder {
        private static final MyMaxRewardedAd INSTANCE = new MyMaxRewardedAd();
    }

    public static MyMaxRewardedAd getInstance(String adUnitId, Context context) {
        if ((context instanceof Activity) && !TextUtils.isEmpty(adUnitId.trim())) {
            MyMaxRewardedAd.SingletonHolder.INSTANCE.mContext = context;
            MyMaxRewardedAd.SingletonHolder.INSTANCE.mAdUnitId = adUnitId;
            MyMaxRewardedAd.SingletonHolder.INSTANCE.mTPReward = new TPReward(context, adUnitId);
        } else {
            LogUtil.i("Error Create an AD that requires acitivity, otherwise it won't load");
        }
        return SingletonHolder.INSTANCE;
    }

    private TPReward getTPReward() {
        return mTPReward;
    }

    public void setCustomParams(Map<String, Object> mLocalExtras) {
        if (mTPReward != null) {
            mTPReward.setCustomParams(mLocalExtras);
        }
    }

    public void setListener(MyMaxRewardedAdListener myRewardedAdListener) {
        if (mTPReward != null) {
            mTPReward.setAllAdLoadListener(new LoadAdEveryLayerListener() {
                @Override
                public void onAdAllLoaded(boolean b) {

                }

                @Override
                public void oneLayerLoadFailed(TPAdError tpAdError, TPAdInfo tpAdInfo) {
                    myRewardedAdListener.oneLayerLoadFailed(tpAdError, tpAdInfo);
                    LogUtil.i("Error: code:" + tpAdError.getErrorCode() + ", Msg:" + tpAdError.getErrorMsg());
                }

                @Override
                public void oneLayerLoaded(TPAdInfo tpAdInfo) {

                }

                @Override
                public void onAdStartLoad(String s) {

                }

                @Override
                public void oneLayerLoadStart(TPAdInfo tpAdInfo) {

                }

                @Override
                public void onBiddingStart(TPAdInfo tpAdInfo) {

                }

                @Override
                public void onBiddingEnd(TPAdInfo tpAdInfo, TPAdError tpAdError) {

                }

                @Override
                public void onAdIsLoading(String s) {

                }
            });
            mTPReward.setAdListener(new RewardAdListener() {
                @Override
                public void onAdLoaded(TPAdInfo tpAdInfo) {
                    myRewardedAdListener.onAdLoaded(tpAdInfo);
                }

                @Override
                public void onAdClicked(TPAdInfo tpAdInfo) {
                    myRewardedAdListener.onAdClicked(tpAdInfo);
                }

                @Override
                public void onAdImpression(TPAdInfo tpAdInfo) {
                    myRewardedAdListener.onAdDisplayed(tpAdInfo);
                }

                @Override
                public void onAdFailed(TPAdError tpAdError) {
                    myRewardedAdListener.onAdLoadFailed(mAdUnitId, tpAdError);
                }

                @Override
                public void onAdClosed(TPAdInfo tpAdInfo) {
                    myRewardedAdListener.onAdClosed(tpAdInfo);
                }

                @Override
                public void onAdReward(TPAdInfo tpAdInfo) {
                    myRewardedAdListener.onUserRewarded(tpAdInfo);
                }

                @Override
                public void onAdVideoStart(TPAdInfo tpAdInfo) {
                    myRewardedAdListener.onRewardedVideoStarted(tpAdInfo);
                }

                @Override
                public void onAdVideoEnd(TPAdInfo tpAdInfo) {
                    myRewardedAdListener.onAdVideoEnd(tpAdInfo);
                }

                @Override
                public void onAdVideoError(TPAdInfo tpAdInfo, TPAdError tpAdError) {
                    myRewardedAdListener.onAdVideoError(tpAdInfo, tpAdError);
                }
            });
        }
    }

    // Load the first ad
    public void loadAd() {
        new Thread(() -> {
            if (mTPReward != null) {
                mTPReward.loadAd();
            }
        }).start();
    }

    public boolean isReady() {
        return mTPReward != null && mTPReward.isReady();
    }

    public void showAd() {
        if (mTPReward != null) {
            if (mContext instanceof Activity) {
                mTPReward.showAd((Activity) mContext, mAdUnitId);
            }
        }
    }

    public void onDestroy() {
        if (mContext != null && mTPReward != null) {
            mTPReward.onDestroy();
        }
    }
}
