/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.my.applovin.sdk;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.my.applovin.sdk";
  public static final String BUILD_TYPE = "release";
  // Field from build type: release
  public static final boolean LOGCAT = false;
  // Field from build type: release
  public static final String VERSION_AAR = "14.9.20.1";
}
