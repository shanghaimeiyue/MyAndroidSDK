package com.my.applovin.util;

import android.util.Log;

import com.my.applovin.sdk.MyAppLovinSdk;

public class LogUtil {
    public static final String TAG = "MySDK";
    public static boolean debug = MyAppLovinSdk.isLogcat;

    public static void i(String msg) {
        if (debug) {
            Log.i(TAG, msg);
        }
    }

    public static void e(String msg) {
        if (debug) {
            Log.e(TAG, msg);
        }
    }
}
