package com.my.applovin.mediation.ads;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.my.applovin.mediation.MyMaxAdViewAdListener;
import com.my.applovin.util.LogUtil;
import com.tradplus.ads.base.bean.TPAdError;
import com.tradplus.ads.base.bean.TPAdInfo;
import com.tradplus.ads.open.LoadAdEveryLayerListener;
import com.tradplus.ads.open.banner.BannerAdListener;
import com.tradplus.ads.open.banner.TPBanner;

import java.lang.ref.WeakReference;
import java.util.Map;

public class MyMaxAdView extends FrameLayout {
    private long RETRY_TIMEOUT = 1500;
    private TPBanner mTPBanner;
    private String mAdUnitId;
    private boolean retryAttempt = true;
    private boolean isLoadAdShow = false;
    private Handler handler = new Handler(Looper.getMainLooper());
    private BannerRunnable bannerRunnable;

    public MyMaxAdView(@NonNull Context context) {
        super(context);
    }

    public MyMaxAdView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public MyMaxAdView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public MyMaxAdView(String adUnitId, Context context) {
        super(context);
        if ((context instanceof Activity) && !TextUtils.isEmpty(adUnitId.trim())) {
            this.mAdUnitId = adUnitId;
            this.mTPBanner = new TPBanner(context);
        } else {
            LogUtil.i("Error Create an AD that requires acitivity, otherwise it won't load");
        }
    }

    private TPBanner getTPBanner() {
        return mTPBanner;
    }

    public void setCustomParams(Map<String, Object> mLocalExtras) {
        if (mTPBanner != null) {
            mTPBanner.setCustomParams(mLocalExtras);
        }
    }

    public void setAdRetryAttempt(long timeout, boolean retryAttempt) {
        this.RETRY_TIMEOUT = Math.max(timeout, RETRY_TIMEOUT);
        this.retryAttempt = retryAttempt;
    }

    public View rootView() {
        return mTPBanner != null ? mTPBanner.getRootView() : null;
    }

    public void setListener(MyMaxAdViewAdListener myMaxAdViewAdListener) {
        if (mTPBanner != null && myMaxAdViewAdListener != null) {
            mTPBanner.setAllAdLoadListener(new LoadAdEveryLayerListener() {
                @Override
                public void onAdAllLoaded(boolean b) {

                }

                @Override
                public void oneLayerLoadFailed(TPAdError tpAdError, TPAdInfo tpAdInfo) {
                    myMaxAdViewAdListener.oneLayerLoadFailed(tpAdError, tpAdInfo);
                    LogUtil.i("Error: code:" + tpAdError.getErrorCode() + ", Msg:" + tpAdError.getErrorMsg());
                }

                @Override
                public void oneLayerLoaded(TPAdInfo tpAdInfo) {

                }

                @Override
                public void onAdStartLoad(String s) {

                }

                @Override
                public void oneLayerLoadStart(TPAdInfo tpAdInfo) {

                }

                @Override
                public void onBiddingStart(TPAdInfo tpAdInfo) {

                }

                @Override
                public void onBiddingEnd(TPAdInfo tpAdInfo, TPAdError tpAdError) {

                }

                @Override
                public void onAdIsLoading(String s) {

                }
            });
            mTPBanner.setAdListener(new BannerAdListener() {

                @Override // 广告加载完成 首个广告源加载成功时回调 一次加载流程只会回调一次
                public void onAdLoaded(TPAdInfo tpAdInfo) {
                    retryAttempt = false;
                    myMaxAdViewAdListener.onAdLoaded(tpAdInfo);
                    LogUtil.i("onAdLoaded Successful unitId: " + tpAdInfo.tpAdUnitId);
                }

                @Override // 广告被点击
                public void onAdClicked(TPAdInfo tpAdInfo) {
                    myMaxAdViewAdListener.onAdClicked(tpAdInfo);
                }

                @Override // 广告成功展示在页面上
                public void onAdImpression(TPAdInfo tpAdInfo) {
                    myMaxAdViewAdListener.onAdDisplayed(tpAdInfo);
                }

                @Override // 广告加载失败
                public void onAdLoadFailed(TPAdError error) {
                    if (retryAttempt) {
                        retryAttempt = false;
                        bannerRunnable = new BannerRunnable(MyMaxAdView.this);
                        handler.postDelayed(bannerRunnable, RETRY_TIMEOUT);
                    } else {
                        LogUtil.i("onAdLoadFailed error:" + error.getErrorCode() + "\n" + error.getErrorMsg());
                        myMaxAdViewAdListener.onAdLoadFailed(mAdUnitId, error);
                    }
                }

                @Override // 广告被关闭
                public void onAdClosed(TPAdInfo tpAdInfo) {
                    myMaxAdViewAdListener.onAdClosed(tpAdInfo);
                }

                @Override
                public void onAdShowFailed(TPAdError error, TPAdInfo tpAdInfo) {
                    super.onAdShowFailed(error, tpAdInfo);
                    myMaxAdViewAdListener.onAdDisplayFailed(tpAdInfo, error);
                    LogUtil.i("onAdShowFailed error:" + error.getErrorCode() + "\n" + error.getErrorMsg());
                }
            });
        }
    }

    private void retryLodingAd() {
        if (mTPBanner != null) {
            mTPBanner.loadAd(mAdUnitId);
        }
    }

    static class BannerRunnable implements Runnable {
        private final WeakReference<MyMaxAdView> activityReference;

        public BannerRunnable(MyMaxAdView adView) {
            this.activityReference = new WeakReference<>(adView);
        }

        @Override
        public void run() {
            MyMaxAdView adView = activityReference.get();
            if (adView != null) {
                adView.retryLodingAd();
            }
        }
    }

    // Load the first ad
    public void loadAd() {
        removeAllViews();
        this.mTPBanner.closeAutoShow();
        new Thread(() -> {
            if (mTPBanner != null && !TextUtils.isEmpty(mAdUnitId.trim())) {
                retryAttempt = true;
                mTPBanner.loadAd(mAdUnitId);
            }
        }).start();
    }

    public void loadAdShow() {
        removeAllViews();
        isLoadAdShow = true;
        if (mTPBanner != null && !TextUtils.isEmpty(mAdUnitId.trim())) {
            retryAttempt = true;
            mTPBanner.loadAd(mAdUnitId);
            addView(mTPBanner);
        }
    }

    public boolean isReady() {
        return mTPBanner != null && mTPBanner.isReady();
    }

    public void showAd() {
        if (mTPBanner != null && !isLoadAdShow) {
            removeAllViews();
            mTPBanner.showAd();
            addView(mTPBanner.getRootView());
        }
    }

    public void onDestroy() {
        if (handler != null) {
            handler.removeCallbacks(bannerRunnable);
            handler.removeCallbacksAndMessages(null);
            handler = null;
        }
        if (mTPBanner != null) {
            retryAttempt = true;
            mTPBanner.onDestroy();
            mTPBanner = null;
        }
    }
}
