package com.my.applovin.mediation;

import com.tradplus.ads.base.bean.TPAdError;
import com.tradplus.ads.base.bean.TPAdInfo;

public interface MyMaxNativeAdListener {

    // 广告加载完成
    void onNativeAdLoaded(final TPAdInfo tpAdInfo);

    // 广告加载失败
    void onNativeAdLoadFailed(final String adUnitId, final TPAdError tpAdError);

    // 广告展示失败
    void onNativeAdShowFailed(final TPAdError tpAdError, final TPAdInfo tpAdInfo);

    // 广告被点击
    void onNativeAdClicked(final TPAdInfo tpAdInfo);

    // 广告被关闭
    void onNativeAdClosed(final TPAdInfo tpAdInfo);

    // 广告成功展示
    void onNativeAdExpired(final TPAdInfo tpAdInfo);

    // 广告失败异常
    void oneLayerLoadFailed(TPAdError tpAdError, TPAdInfo tpAdInfo);

}
