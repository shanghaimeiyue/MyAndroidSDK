package com.my.applovin.mediation.ads;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;

import com.my.applovin.mediation.MyMaxAdListener;
import com.my.applovin.util.LogUtil;
import com.tradplus.ads.base.bean.TPAdError;
import com.tradplus.ads.base.bean.TPAdInfo;
import com.tradplus.ads.open.LoadAdEveryLayerListener;
import com.tradplus.ads.open.interstitial.InterstitialAdListener;
import com.tradplus.ads.open.interstitial.TPInterstitial;

import java.util.Map;

public class MyMaxInterstitialAd {

    private TPInterstitial mTPInterstitial;

    private Context mContext;
    private String mAdUnitId;

    public MyMaxInterstitialAd(String adUnitId, Context context) {
        if ((context instanceof Activity) && !TextUtils.isEmpty(adUnitId.trim())) {
            this.mContext = context;
            this.mAdUnitId = adUnitId;
            this.mTPInterstitial = new TPInterstitial(context, adUnitId);
        } else {
            LogUtil.i("Error Create an AD that requires acitivity, otherwise it won't load");
        }
    }

    private TPInterstitial getTPReward() {
        return mTPInterstitial;
    }

    public void setCustomParams(Map<String, Object> mLocalExtras) {
        if (mTPInterstitial != null) {
            mTPInterstitial.setCustomParams(mLocalExtras);
        }
    }

    public void setListener(MyMaxAdListener maxAdListener) {
        if (mTPInterstitial != null && maxAdListener != null) {
            mTPInterstitial.setAllAdLoadListener(new LoadAdEveryLayerListener() {
                @Override
                public void onAdAllLoaded(boolean b) {

                }

                @Override
                public void oneLayerLoadFailed(TPAdError tpAdError, TPAdInfo tpAdInfo) {
                    maxAdListener.oneLayerLoadFailed(tpAdError, tpAdInfo);
                    LogUtil.i("Error: code:" + tpAdError.getErrorCode() + ", Msg:" + tpAdError.getErrorMsg());
                }

                @Override
                public void oneLayerLoaded(TPAdInfo tpAdInfo) {

                }

                @Override
                public void onAdStartLoad(String s) {

                }

                @Override
                public void oneLayerLoadStart(TPAdInfo tpAdInfo) {

                }

                @Override
                public void onBiddingStart(TPAdInfo tpAdInfo) {

                }

                @Override
                public void onBiddingEnd(TPAdInfo tpAdInfo, TPAdError tpAdError) {

                }

                @Override
                public void onAdIsLoading(String s) {

                }
            });
            mTPInterstitial.setAdListener(new InterstitialAdListener() {
                @Override
                public void onAdLoaded(TPAdInfo tpAdInfo) {
                    maxAdListener.onAdLoaded(tpAdInfo, null);
                }

                @Override
                public void onAdFailed(TPAdError tpAdError) {
                    maxAdListener.onAdLoadFailed(tpAdError);
                }

                @Override
                public void onAdImpression(TPAdInfo tpAdInfo) {
                    maxAdListener.onAdDisplayed(tpAdInfo);
                }

                @Override
                public void onAdClicked(TPAdInfo tpAdInfo) {
                    maxAdListener.onAdClicked(tpAdInfo);
                }

                @Override
                public void onAdClosed(TPAdInfo tpAdInfo) {
                    maxAdListener.onAdClosed(tpAdInfo);
                }

                @Override
                public void onAdVideoError(TPAdInfo tpAdInfo, TPAdError tpAdError) {

                }

                @Override
                public void onAdVideoStart(TPAdInfo tpAdInfo) {

                }

                @Override
                public void onAdVideoEnd(TPAdInfo tpAdInfo) {

                }
            });
        }
    }

    // Load the first ad
    public void loadAd() {
        if (mTPInterstitial != null) {
            mTPInterstitial.loadAd();
        }
    }

    public boolean isReady() {
        return mTPInterstitial != null && mTPInterstitial.isReady();
    }

    public void showAd() {
        if (mTPInterstitial != null) {
            if (mContext instanceof Activity) {
                mTPInterstitial.showAd((Activity) mContext, mAdUnitId);
            }
        }
    }

    public void onDestroy() {
        if (mContext != null && mTPInterstitial != null) {
            mTPInterstitial.onDestroy();
        }
    }
}
